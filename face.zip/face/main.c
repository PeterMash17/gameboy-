#include <stdio.h>
#include <gb/gb.h>
#include "emoji.c"

/*  for right side  of the face

    SPRITES_8x16;
    set_sprite_data(0,8,smile);
    set_sprite_tile(1,2);
    move_sprite(1,75+8,75);
    SHOW_SPRITES;
    */

/*  for left side of the face
    
    SPRITES_8x16;
    set_sprite_data(0,8,smile);
    set_sprite_tile(0,0);
    move_sprite(0,75,75);
    SHOW_SPRITES;
*/

/* for both sides of the face
    SPRITES_8x16;
    set_sprite_data(0,8,smile);
    set_sprite_tile(0,0);
    move_sprite(0,75,75);
    set_sprite_tile(1,2);
    move_sprite(1,75+8,75);
    SHOW_SPRITES;
*/

/* another animation / effect
SPRITES_8x16;
    set_sprite_data(0,8,smile);
    set_sprite_tile(0,0);
    move_sprite(0,75,75);
    set_sprite_tile(1,2);
    move_sprite(1,75+8,75);
    SHOW_SPRITES;

    while(1){
        set_sprite_tile(1,6);
        delay(300);
        set_sprite_tile(1,2);
        delay(300);
    }
*/


void main(){
    // a litte animation / effect

    SPRITES_8x16;
    set_sprite_data(0,8,smile);
    set_sprite_tile(0,0);
    move_sprite(0,75,75);
    set_sprite_tile(1,2);
    move_sprite(1,75+8,75+8);
    SHOW_SPRITES;

    while(1){
        delay(800);
        move_sprite(1,75+8,75);
        delay(500);
        move_sprite(0,75,75+8);
        // finish animation
        delay(800);
        move_sprite(0,75,75);
        break;
    }
}